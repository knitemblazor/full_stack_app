async function login() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    console.log("entered script");

    try {
        const response = await fetch("/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ email, password }),
            timeout: 5000 // Timeout in milliseconds (adjust as needed)
        });

        if (response.ok) {
            // Redirect to dashboard or another page upon successful login
            window.location.href = "/dashboard.html";
        } else {
            console.log("login failed");
            const data = await response.json();
            alert(data.detail); // Display error message returned from the backend
        }
    } catch (error) {
        console.error("Error:", error);
        if (error instanceof TypeError) {
            alert("Unable to reach the server. Please try again later.");
        } else {
            alert("An unexpected error occurred.");
        }
    }
}
