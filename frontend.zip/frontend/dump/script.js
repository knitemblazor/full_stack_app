async function createDocument() {
    const name = document.getElementById("name").value;
    const age = parseInt(document.getElementById("age").value);
    const city = document.getElementById("city").value;

    await fetch("/create", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ name, age, city })
    });

    document.getElementById("output").innerText = "Document created successfully.";
}

async function readDocument() {
    const response = await fetch("/read");
    const data = await response.json();

    document.getElementById("output").innerText = JSON.stringify(data);
}

async function updateDocument() {
    const name = document.getElementById("name").value;
    const city = document.getElementById("city").value;

    await fetch("/update", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ name, city })
    });

    document.getElementById("output").innerText = "Document updated successfully.";
}

async function deleteDocument() {
    const name = document.getElementById("name").value;

    await fetch("/delete", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ name })
    });

    document.getElementById("output").innerText = "Document deleted successfully.";
}
