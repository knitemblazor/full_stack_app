
const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    try {
        const url = new URL("http://localhost:3000/login");
        url.searchParams.append("email", email);
        url.searchParams.append("password", password);

        const response = await fetch(url, {
            method: "GET",
            headers: { "Content-Type": "application/json" }
        });

        const data = await response.json();
        if (data.message === "Login successful") {
            window.location.href = 'login_success.html';

        } else {
            alert("Invalid email or password");
        }
    } catch (error) {
        console.error("Error:", error);
    }
});
