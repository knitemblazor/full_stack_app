// const http = require('http');
// const fs = require('fs');

// const port = process.env.PORT || 3300; // Use environment variable or default to 3000

// const server = http.createServer((req, res) => {
//     if (req.url === '/') {
//         fs.readFile('index.html', (err, data) => {
//             if (err) {
//                 res.writeHead(404);
//                 res.write('404 Not Found');
//             } else {
//                 res.writeHead(200, { 'Content-Type': 'text/html' });
//                 res.write(data);
//             }
//             res.end();
//         });
//     } else {
//         res.writeHead(404);
//         res.write('404 Not Found');
//         res.end();
//     }
// });

// server.listen(port, () => {
//     console.log(`Server running at http://localhost:${port}`);
// });


const express = require('express');
const path = require('path');  // Added for path handling

const app = express();
const port = process.env.PORT || 3300;

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

